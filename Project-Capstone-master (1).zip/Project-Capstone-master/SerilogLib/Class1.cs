﻿namespace SerilogLib
{
    public class Class1
    {

    }
}