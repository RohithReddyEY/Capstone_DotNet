﻿namespace CartMicroservice.Models.dto
{
    public class cartFromFrontEnd
    {


            public int userId { get; set; }
            public int productId { get; set; }
         public int productPrice { get; set; }
    }
}
