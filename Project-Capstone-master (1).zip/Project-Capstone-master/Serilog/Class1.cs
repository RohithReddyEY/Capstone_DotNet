﻿namespace Serilog
{
    public class Class1
    {

    }
}