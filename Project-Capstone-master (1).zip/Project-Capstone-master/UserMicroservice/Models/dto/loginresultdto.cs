﻿namespace UserMicroservice.Models.dto
{
    public class loginresultdto
    {   
        public string Token { get; set; }
        public string Username { get; set; }
        public int UserId { get; set; }
    }
}
