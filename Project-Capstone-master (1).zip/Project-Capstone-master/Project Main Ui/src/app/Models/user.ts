
//model used for getting the user data and sending the used data

export interface User {

    Id:number

    FirstName  :string
    LastName  :string

    Username  :string
    Email  :string
    Password  :string
    Token  :string
    Role  :string
    PhoneNumber:string


}