//model used toe send the relevent information to cart

export interface Cart {

   

    userId  :number
    productId  :number
    productPrice: number


  


}